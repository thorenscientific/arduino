#Flappy Ball

For the [Arduboy](https://www.arduboy.com/) Arduino based game system.

Try to overcome the force of gravity and navigate a levitating ball through small openings.
