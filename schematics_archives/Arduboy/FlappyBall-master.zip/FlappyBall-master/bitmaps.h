#include <avr/pgmspace.h>
#ifndef BITMAPS_H
#define BITMAPS_H

extern const unsigned char floatyball[];
extern const unsigned char gameover[];

#endif

