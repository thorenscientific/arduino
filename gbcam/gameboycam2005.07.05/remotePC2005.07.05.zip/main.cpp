/**
 * @file       main.cpp
 * @brief      Basic program to communication with the camera board and take a picture
 * 
 * @author     Laurent Saint-Marcel (lstmarcel@yahoo.fr)
 * @date       2005/05/5
 */

#include "stdafx.h"
#include "serial.h"
#include "Jpegfile.h"
#include "../camCom.h"

#ifndef DEBUG
#define DEBUG
#endif

#define ERROR_SERIAL 1
#define SUCCESS		 0

BYTE msg[255];

serialCL serial;

void uartWrite(BYTE data)
{
	msg[0]=data;
	if(serial.write(msg, 1) != SERIAL_SUCCESS) {
		printf("Write Error\n");
	}
}

BYTE uartRecv()
{
	unsigned long l=1;
	serial.forceRead(msg, l);
	return msg[0];
}

BYTE uartRecvNobloking()
{
	unsigned long l=1;
	msg[0]=0x00;
	serial.read(msg, l);
	return msg[0];
}

struct Pixel {
	BYTE r;
	BYTE g;
	BYTE b;
	Pixel(BYTE grey): r(grey), g(grey), b(grey) {}
	Pixel() : r(0), g(0), b(0xFF) {}
};

// set the 8 registers of the camera
void setRegisters()
{
	uartWrite(CAM_COM_SET_REGISTERS);
	uartWrite(0x80);
	uartWrite(0x03);
	uartWrite(0x00); // exposure 
	uartWrite(0x30); // exposure time change this to adjust picture light 
	uartWrite(0x01);
	uartWrite(0x00);
	uartWrite(0x01);
	uartWrite(0x23);
}

// take a picture and save it in a Jpeg file
void readPicture(const char* filename,
				 BYTE pixMin,
				 BYTE pixMax) 
{
	BYTE data=0;
	unsigned char vMin=0xFF;
	unsigned char vMax=0;
	double        vAverage=0;
	unsigned long pixelCount=0;
	unsigned long picSize=128*128;
	Pixel* picture=new Pixel[picSize]; 

	// take a picture
	uartWrite(CAM_COM_TAKE_PICTURE);

	// wait data reception
	while(1) {
		data=uartRecv();
		switch(data) {
		case CAM_COM_SEND_START:
			printf("Take Picture\n");
			break;
		case CAM_COM_START_READ:
		{
			printf("Start receiving picture. Please wait...\n"); 
			while(pixelCount < picSize) {
				data=uartRecv();
				if (data == CAM_COM_STOP_READ)
					break;
				if (data > vMax) vMax = data;
				if (data < vMin) vMin = data;
				vAverage += ((data/128.)/128.);
				picture[pixelCount] = Pixel((BYTE)((data-pixMin)*255./(pixMax-pixMin)));
				pixelCount++;	
			}
			printf("Picture received:\n"
				   "  Size=%d bytes (expected: %d bytes) = 128 x %d \n"
				   "  Pixels info: min=0x%2.2x, max=0x%2.2x, average=0x%2.2x=%3.3lf\n", 
					pixelCount, picSize, pixelCount/128, 
					vMin, vMax, (int)vAverage, vAverage);
			JpegFile::RGBToJpegFile("img.jpg",				// path
						   (BYTE*)picture,					// RGB buffer
						   128,						        // width
						   128,					            // height
						   true,						    // TRUE = RGB
						   99);                             // quality
			return;

		} 
		break;
		case CAM_COM_STOP_READ:
			printf("Receiving end\n"); 
			break;
		default:
			printf("Unknown command received: 0x%2.2x (%d)\n", data, data);
			break;
		}
	}
}
/////////////////////////////////////////
int main(int argc, char* argv[])
{
	
	printf("GameBoyCamera to PC\n");
	printf("-------------------\n");
	printf("More info on http://sophiateam.undergnd.free.fr\n\n");

	int result;
	/* open serial port */
	result = serial.open("COM1", 38400);
	if(result != SERIAL_SUCCESS) {
		printf("Unable to open serial port\nEnding with error\n");
		return 1;
	}

	// test communication:
	uartWrite(CAM_COM_PING);
	if (uartRecv() == CAM_COM_PONG) {
		uartWrite(CAM_COM_SET_CLOCK_SPEED);
		setRegisters();
		readPicture("img.jpg", 0x1a, 0x4A);
	} else {
		printf("Error, serial communication error. Camera not pinging.\n");	
	}

	/* close serial port */
	serial.close();
	printf("Bye...\n");
	return 0;
}

