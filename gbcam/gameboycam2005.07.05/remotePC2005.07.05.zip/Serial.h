#ifndef __SERIAL_H_LSM__
#define __SERIAL_H_LSM__

#include <windows.h>
#include <commctrl.h>

#define DEFAULT_READ_TIMEOUT      500      // milliseconds

#ifdef SERIAL_ERROR
#undef SERIAL_ERROR
#endif

#ifdef SERIAL_SUCCESS
#undef SERIAL_SUCCESS
#endif


#define SERIAL_ERROR	-1
#define SERIAL_SUCCESS	0

#define DEFAULT_PORT_NAME	"COM1"

class serialCL{

public :
	serialCL();
	~serialCL();
	int open(char* gszPort = DEFAULT_PORT_NAME, 
				long speed = 9600, 
				int parity = NOPARITY, 
				int bitslength = 8, 
				int stopbit = ONESTOPBIT);

	int close();

	int read(unsigned char * buffer, 
				unsigned long & length);
	int forceRead(unsigned char * lpBuf, 
				  unsigned long &length,
				  int retry=-2); // infinite retry

	int write(unsigned char * buffer, 
				unsigned long length);

private :
	char gszPort_[256];
	HANDLE CommPortHandle; //Holds the handle to the communications port returned by windows.
	COMMTIMEOUTS CommPortTimeOut; // This data structure is programmed with timeout parameters for the serial port
	DCB CommPortDCB; // This data structure is programmed with the serial port parameters.
	short PortInitSuccessful; // This data member is assigned 1 if the serial port is successfully initialized, otherwise it is 0.
	unsigned long BytesTransferred; // Holds the number of bytes transferred during a serial port read or write operation. This is here just as a placeholder for windows API functions.

};

#endif