//-----------------------------------------------------//
// Base class for SERIAL_COMMUNICATION, nonoverlapped  //
// Laurent SAINT-MARCEL	--	july, 31th 2001			   //
//-----------------------------------------------------//
#include <stdafx.h>
#include <stdio.h>
#include "serial.h"


///////////////////////////////////////
// serialCL - Constructor, destructor
///////////////////////////////////////
serialCL::serialCL()
{
	CommPortHandle = 0;
}

serialCL::~serialCL()
{

}

//////////////////////////////////
// open
//////////////////////////////////
int serialCL::open(char * gszPort, long speed, int parity, int bitslength, int stopbit)
{

	CommPortTimeOut.ReadIntervalTimeout = 2; 
	CommPortTimeOut.ReadTotalTimeoutMultiplier = 1; 
	CommPortTimeOut.ReadTotalTimeoutConstant = 1; 
	CommPortTimeOut.WriteTotalTimeoutMultiplier = 0; 
	CommPortTimeOut.WriteTotalTimeoutConstant = 0; 

	PortInitSuccessful = 1; 
	strcpy(gszPort_, gszPort);
	// close serial port if already opened
	if(CommPortHandle != 0) close();

    // Code for opening CommPortHandle using CreateFile goes here 
	CommPortHandle = CreateFile( gszPort_, 
                     GENERIC_READ | GENERIC_WRITE, 
                     0, 
                     0, 
                     OPEN_EXISTING, 
                     NULL, 
                     0); 

	if(CommPortHandle == INVALID_HANDLE_VALUE) 
	{  
			//printf("CreateFile ERROR\n");
			PortInitSuccessful = 0; 
			return SERIAL_ERROR;
	} 
	else 
	{  //Code implemented only for a valid handle 
      if(!SetCommTimeouts(CommPortHandle,&CommPortTimeOut)) 
      {  
			//printf("SetCommTimeouts failed"); 
			PortInitSuccessful = 0; 
			return SERIAL_ERROR;
      } 

      // clear the memory used by the CommPortDCB object 
      memset(&CommPortDCB,0,sizeof(CommPortDCB)); 

      // set DCB 
      CommPortDCB.DCBlength =	sizeof(CommPortDCB); 
      CommPortDCB.BaudRate =	speed; 
      CommPortDCB.Parity =		parity; 
      CommPortDCB.StopBits =	stopbit; 
      CommPortDCB.ByteSize =	bitslength; 

      if(!SetCommState(CommPortHandle,&CommPortDCB)) 
      {  
			//printf("SetCommState failed");
			PortInitSuccessful = 0; 
			return SERIAL_ERROR;
      } 
	} 
	return SERIAL_SUCCESS;
}

//////////////////////////////////
// close
//////////////////////////////////
int serialCL::close()
{
	if(CommPortHandle!=0)
		CloseHandle(CommPortHandle);
	CommPortHandle = 0;
	return SERIAL_SUCCESS;
}

//////////////////////////////////
// read
//////////////////////////////////
int serialCL::read(unsigned char * lpBuf, unsigned long &length)
{
	if( !ReadFile(CommPortHandle, lpBuf, length, &BytesTransferred, NULL) ) 
	{
		return SERIAL_ERROR;
	}
	if(BytesTransferred != length)
		return SERIAL_ERROR;
	return SERIAL_SUCCESS;
}

//////////////////////////////////
// force read
//////////////////////////////////
int serialCL::forceRead(unsigned char * lpBuf, unsigned long &length, int retry)
{
	unsigned long l2 = 0;
	while(l2!=length && retry!=-1) {
		if( !ReadFile(CommPortHandle, lpBuf+l2, length-l2, &BytesTransferred, NULL) ) 
		{
			return SERIAL_ERROR;
		}	
		l2+=BytesTransferred;
		--retry;
		if(retry<-1) retry=-2;
	}
	length = BytesTransferred;
	if(l2==length)
		return SERIAL_SUCCESS;
	else
		return SERIAL_ERROR;
}

//////////////////////////////////
// write
//////////////////////////////////
int serialCL::write(unsigned char * lpBuf, unsigned long length)
{
	if( !WriteFile(CommPortHandle, lpBuf, length, &BytesTransferred, NULL) )
	{
		return SERIAL_ERROR;
	}
	if(BytesTransferred != length)
		return SERIAL_ERROR;
	return SERIAL_SUCCESS;
}


